﻿$(document).ready( function () {
        $('#WEATHER').DataTable();
    } );

function celsius_para_fahrenheit(celsius) {
    var temperatura_celsius = celsius;
    var conversao = temperatura_celsius * 9 / 5 + 32;
    return conversao;
    console.log(conversao);
}

function fahrenheit_para_celsius(fahrenheit) {
    var temperatura_fahrenheit = fahrenheit;
    var conversao = (temperatura_fahrenheit - 32) * 5 / 9;
    return conversao;
    console.log(conversao);
}


function buscar_dados_pela_localizacao_atual() {

    const chave_api = '9007a57b713ded2cab57517001962537';

    navigator.geolocation.getCurrentPosition((success) => {

        let { latitude, longitude } = success.coords;

        fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&exclude=hourly,minutely&units=metric&appid=${chave_api}`).then(res => res.json()).then(data => {
            console.log(data)
            showWeatherData(data);
        })

    })
}





window.onload = function busca_info_estatico() {

    var cidade1 = "Lisboa";
    var cidade2 = "Coimbra";
    var cidade3 = "Leiria";
    var cidade4 = "Berlim";
    var cidade5 = "Ohio";
    var cidade6 = "Pequim";

    var local1 = document.querySelector('#local1');
    var local2 = document.querySelector('#local2');
    var local3 = document.querySelector('#local3');
    var local4 = document.querySelector('#local4');
    var local5 = document.querySelector('#local5');
    var local6 = document.querySelector('#local6');

    var temp1 = document.querySelector('#temp1');
    var temp2 = document.querySelector('#temp2');
    var temp3 = document.querySelector('#temp3');
    var temp4 = document.querySelector('#temp4');
    var temp5 = document.querySelector('#temp5');
    var temp6 = document.querySelector('#temp6');

    var chuva1 = document.querySelector('#chuva1');
    var chuva2 = document.querySelector('#chuva2');
    var chuva3 = document.querySelector('#chuva3');
    var chuva4 = document.querySelector('#chuva4');
    var chuva5 = document.querySelector('#chuva5');
    var chuva6 = document.querySelector('#chuva6');

    var vento1 = document.querySelector('#vento1');
    var vento2 = document.querySelector('#vento2');
    var vento3 = document.querySelector('#vento3');
    var vento4 = document.querySelector('#vento4');
    var vento5 = document.querySelector('#vento5');
    var vento6 = document.querySelector('#vento6');



        fetch('https://api.openweathermap.org/data/2.5/weather?q='+cidade1+'&appid=9007a57b713ded2cab57517001962537&units=metric')
        .then(response => response.json())
        .then(data => {

            var tempoValor = data['main']['temp'];
            var nameValor = data['name'];
            var chuvaValor = data['main']['humidity'];
            var ventoValor = data['wind']['speed'];
            var nuvemValor = data['weather'][0]['icon'];

            local1.innerHTML = nameValor;
            temp1.innerHTML =  tempoValor;
            chuva1.innerHTML = chuvaValor + "%";
            vento1.innerHTML = ventoValor + " m/s";
            document.getElementById("nuvens1").src = "http://openweathermap.org/img/wn/"+nuvemValor+"@2x.png";


        })
        .catch(err => alert("Erro"));

        fetch('https://api.openweathermap.org/data/2.5/weather?q='+cidade2+'&appid=9007a57b713ded2cab57517001962537&units=metric')
        .then(response => response.json())
        .then(data => {

            var tempoValor = data['main']['temp'];
            var nameValor = data['name'];
            var chuvaValor = data['main']['humidity'];
            var ventoValor = data['wind']['speed'];
            var nuvemValor = data['weather'][0]['icon'];


            local2.innerHTML = nameValor;
            temp2.innerHTML = tempoValor;
            chuva2.innerHTML = chuvaValor + "%";
            vento2.innerHTML = ventoValor + " m/s";
            document.getElementById("nuvens2").src = "http://openweathermap.org/img/wn/"+nuvemValor+"@2x.png";



        })
        .catch(err => alert("Erro"));

        fetch('https://api.openweathermap.org/data/2.5/weather?q='+cidade3+'&appid=9007a57b713ded2cab57517001962537&units=metric')
        .then(response => response.json())
        .then(data => {

            var tempoValor = data['main']['temp'];
            var nameValor = data['name'];
            var chuvaValor = data['main']['humidity'];
            var ventoValor = data['wind']['speed'];
            var nuvemValor = data['weather'][0]['icon'];


            local3.innerHTML = nameValor;
            temp3.innerHTML = tempoValor;
            chuva3.innerHTML = chuvaValor + "%";
            vento3.innerHTML = ventoValor + " m/s";
            document.getElementById("nuvens3").src = "http://openweathermap.org/img/wn/"+nuvemValor+"@2x.png";



        })
        .catch(err => alert("Erro"));

        fetch('https://api.openweathermap.org/data/2.5/weather?q='+cidade4+'&appid=9007a57b713ded2cab57517001962537&units=metric')
        .then(response => response.json())
        .then(data => {

            var tempoValor = data['main']['temp'];
            var nameValor = data['name'];
            var chuvaValor = data['main']['humidity'];
            var ventoValor = data['wind']['speed'];
            var nuvemValor = data['weather'][0]['icon'];


            local4.innerHTML = nameValor;
            temp4.innerHTML = tempoValor;
            chuva4.innerHTML = chuvaValor + "%";
            vento4.innerHTML = ventoValor + " m/s";
            document.getElementById("nuvens4").src = "http://openweathermap.org/img/wn/"+nuvemValor+"@2x.png";



        })
        .catch(err => alert("Erro"));

        fetch('https://api.openweathermap.org/data/2.5/weather?q='+cidade5+'&appid=9007a57b713ded2cab57517001962537&units=metric')
        .then(response => response.json())
        .then(data => {

            var tempoValor = data['main']['temp'];
            var nameValor = data['name'];
            var chuvaValor = data['main']['humidity'];
            var ventoValor = data['wind']['speed'];
            var nuvemValor = data['weather'][0]['icon'];


            local5.innerHTML = nameValor;
            temp5.innerHTML = tempoValor;
            chuva5.innerHTML = chuvaValor + "%";
            vento5.innerHTML = ventoValor + " m/s";
            document.getElementById("nuvens5").src = "http://openweathermap.org/img/wn/"+nuvemValor+"@2x.png";



        })
        .catch(err => alert("Erro"));

        fetch('https://api.openweathermap.org/data/2.5/weather?q='+cidade6+'&appid=9007a57b713ded2cab57517001962537&units=metric')
        .then(response => response.json())
        .then(data => {
            var tempoValor = data['main']['temp'];
            var nameValor = data['name'];
            var chuvaValor = data['main']['humidity'];
            var ventoValor = data['wind']['speed'];
            var nuvemValor = data['weather'][0]['icon'];


            local6.innerHTML = nameValor;
            temp6.innerHTML = tempoValor;
            chuva6.innerHTML = chuvaValor + "%";
            vento6.innerHTML = ventoValor + " m/s";
            document.getElementById("nuvens6").src = "http://openweathermap.org/img/wn/"+nuvemValor+"@2x.png";



        })
        .catch(err => alert("Erro"));

}

function favorito1() {
    var img = document.getElementById("fav1");
    if (img.style.visibility === "hidden") {
        img.style.visibility = "visible";
    }
    else {
        img.style.visibility = "hidden";
    }
}

function favorito2() {
    var img = document.getElementById("fav2");
    if (img.style.visibility === "hidden") {
        img.style.visibility = "visible";
    }
    else {
        img.style.visibility = "hidden";
    }
}

function favorito3() {
    var img = document.getElementById("fav3");
    if (img.style.visibility === "hidden") {
        img.style.visibility = "visible";
    }
    else {
        img.style.visibility = "hidden";
    }
}

function favorito4() {
    var img = document.getElementById("fav4");
    if (img.style.visibility === "hidden") {
        img.style.visibility = "visible";
    }
    else {
        img.style.visibility = "hidden";
    }
}

function favorito5() {
    var img = document.getElementById("fav5");
    if (img.style.visibility === "hidden") {
        img.style.visibility = "visible";
    }
    else {
        img.style.visibility = "hidden";
    }
}

function favorito6() {
    var img = document.getElementById("fav6");
    if (img.style.visibility === "hidden") {
        img.style.visibility = "visible";
    }
    else {
        img.style.visibility = "hidden";
    }
}